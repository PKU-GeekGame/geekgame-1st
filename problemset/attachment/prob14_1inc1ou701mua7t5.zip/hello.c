/* Is this the simplest C program ? */
int a = 0;

int main() {
    return 0;
}